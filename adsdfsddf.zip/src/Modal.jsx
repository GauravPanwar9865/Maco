@media (min-width: 1025px) {
  .h-custom {
  height: 100vh !important;
  }
  }
  
  .card-registration .select-input.form-control[readonly]:not([disabled]) {
  font-size: 1rem;
  line-height: 2.15;
  padding-left: .75em;
  padding-right: .75em;
  }
  
  .card-registration .select-arrow {
  top: 13px;
  }
  
  .bg-grey {
  background-color: #eae8e8;
  }
  
  @media (min-width: 992px) {
  .card-registration-2 .bg-grey {
  border-top-right-radius: 16px;
  border-bottom-right-radius: 16px;
  }
  }
  
  @media (max-width: 991px) {
  .card-registration-2 .bg-grey {
  border-bottom-left-radius: 16px;
  border-bottom-right-radius: 16px;
  }
  }